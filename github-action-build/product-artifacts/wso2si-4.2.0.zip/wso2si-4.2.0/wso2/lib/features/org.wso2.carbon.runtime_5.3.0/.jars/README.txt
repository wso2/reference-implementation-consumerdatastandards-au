You can include all third party non-OSGI JARs to this directory.
Non-osgi JARs will be converted to OSGI bundles and copied to <CARBON_HOME>/lib directory when install-jars.sh/install-jars.bat tool is executed.
