This directory contains all OSGi specific stuff in Carbon. Usages of each and
every directory are as follows.

1. plugins
   This contains all OSGi bundles that are used to run the server.

2. p2
   Contains Carbon provisioning (p2) related configuration files.
