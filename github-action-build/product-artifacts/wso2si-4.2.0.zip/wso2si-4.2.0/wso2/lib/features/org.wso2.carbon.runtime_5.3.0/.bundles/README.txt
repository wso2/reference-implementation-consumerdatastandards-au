You can include OSGI bundles and Siddhi Extensions in this directory.
All bundles within this directory will be copied to <CARBON_HOME>/lib directory when install-jars.sh/install-jars.bat tool is executed.
Siddhi extension JARs bundled in <CARBON_HOME>/lib will be updated by the extensions available within this directory.
